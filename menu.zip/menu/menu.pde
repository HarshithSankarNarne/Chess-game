import processing.sound.*;

SoundFile clickSound;
SoundFile bgMusic;
PImage bgImage;
PFont menuFont;
PFont titleFont;
int menuState = 0;
int gameMode = 0;

int easyScore = 0;
int medScore = 0;
int hardScore = 0;
int totalXP = 0;

class UI {
  float x, y, w, h;
  String label;

  UI(float x, float y, float w, float h, String label) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.label = label;
  }

  boolean isHovered() {
    return mouseX >= x - w / 2 && mouseX <= x + w / 2 && mouseY >= y - h / 2 && mouseY <= y + h / 2;
  }

  void display() {
    textFont(menuFont);
    textAlign(CENTER, CENTER);
    textSize(28);

    fill(0, 80);
    text(label, x + 2, y + 2);

    if (isHovered()) {
      fill(255, 220, 100, 230);
      cursor(HAND);
    } else {
      fill(255, 200);
    }
    text(label, x, y);
  }
}

UI btnPuzzles, btnNormal, btnLeader, btnHow, btnQuit;
UI btnEasy, btnMed, btnHard, btnBackDiff;
UI btnBackHow, btnBackLeader;

void setup() {
  size(800, 800);
  smooth(8);

  menuFont = createFont("Georgia", 28);
  titleFont = createFont("Georgia", 64);

  bgImage = loadImage("bg.jpg");
  clickSound = new SoundFile(this, "click.wav");
  bgMusic = new SoundFile(this, "music.mp3");
  bgMusic.loop();

  float cx = width / 2;
  float bw = 320;
  float bh = 44;

  btnPuzzles = new UI(cx, 300, bw, bh, "Play Puzzles");
  btnNormal  = new UI(cx, 365, bw, bh, "Play Match");
  btnLeader  = new UI(cx, 430, bw, bh, "Leaderboard");
  btnHow     = new UI(cx, 495, bw, bh, "How To Play");
  btnQuit    = new UI(cx, 560, bw, bh, "Quit");

  btnEasy     = new UI(cx, 340, bw, bh, "Easy");
  btnMed      = new UI(cx, 405, bw, bh, "Medium");
  btnHard     = new UI(cx, 470, bw, bh, "Hard");
  btnBackDiff = new UI(cx, 555, bw, bh, "Back");

  btnBackHow    = new UI(cx, 640, bw, bh, "Back");
  btnBackLeader = new UI(cx, 640, bw, bh, "Back");
}

void draw() {
  if (bgImage != null) {
    image(bgImage, 0, 0, width, height);
  } else {
    background(40, 50, 60);
  }

  noStroke();
  fill(0, 100);
  rect(0, 0, width, height);

  cursor(ARROW);

  if (menuState == 0) {
    drawTitle("Ultimate\nChess Trainer", 180);
    btnPuzzles.display();
    btnNormal.display();
    btnLeader.display();
    btnHow.display();
    btnQuit.display();

  } else if (menuState == 1) {
    if (gameMode == 0) {
      drawTitle("Puzzle Difficulty", 200);
    } else {
      drawTitle("Match Difficulty", 200);
    }
    btnEasy.display();
    btnMed.display();
    btnHard.display();
    btnBackDiff.display();

  } else if (menuState == 2) {
    drawTitle("How To Play", 150);

    textFont(menuFont);
    textSize(20);
    textAlign(CENTER, CENTER);
    textLeading(36);

    String instructions = "Select a game mode and difficulty.\nSolve puzzles or play a full match.\nFailing to solve a puzzle costs one of your 3 lives.\n\nPress H for a hint.\nPress M to return to the menu.";

    fill(0, 90);
    text(instructions, width / 2 + 2, 370 + 2);
    fill(255, 210);
    text(instructions, width / 2, 370);

    btnBackHow.display();
    
  } else if (menuState == 3) {
    drawTitle("Leaderboard", 150);
    
    textFont(menuFont);
    textSize(28);
    textAlign(CENTER, CENTER);
    textLeading(50);
    
    String stats = "Easy High Score: " + easyScore + "\n" +
                   "Medium High Score: " + medScore + "\n" +
                   "Hard High Score: " + hardScore + "\n\n" +
                   "Total XP: " + totalXP;
                   
    fill(0, 90);
    text(stats, width / 2 + 2, 370 + 2);
    fill(255, 210);
    text(stats, width / 2, 370);
    
    btnBackLeader.display();
  }
}

void drawTitle(String txt, float y) {
  textFont(titleFont);
  textAlign(CENTER, CENTER);
  textSize(64);

  fill(0, 100);
  text(txt, width / 2 + 3, y + 3);
  fill(255, 230);
  text(txt, width / 2, y);
}

void mousePressed() {
  if (menuState == 0) {
    if (btnPuzzles.isHovered()) {
      clickSound.play();
      gameMode = 0;
      menuState = 1;
    } else if (btnNormal.isHovered()) {
      clickSound.play();
      gameMode = 1;
      menuState = 1;
    } else if (btnLeader.isHovered()) {
      clickSound.play();
      menuState = 3;
    } else if (btnHow.isHovered()) {
      clickSound.play();
      menuState = 2;
    } else if (btnQuit.isHovered()) {
      clickSound.play();
      delay(150);
      exit();
    }
  } else if (menuState == 1) {
    if (btnEasy.isHovered() || btnMed.isHovered() || btnHard.isHovered()) {
      clickSound.play();
    } else if (btnBackDiff.isHovered()) {
      clickSound.play();
      menuState = 0;
    }
  } else if (menuState == 2) {
    if (btnBackHow.isHovered()) {
      clickSound.play();
      menuState = 0;
    }
  } else if (menuState == 3) {
    if (btnBackLeader.isHovered()) {
      clickSound.play();
      menuState = 0;
    }
  }
}
