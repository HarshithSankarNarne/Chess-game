class Player {

  String name;
  boolean isWhite;
  boolean isBlack;
  boolean isHuman;
  int score;

  Player(String name, boolean isWhite, boolean isHuman, boolean isBlack) {
    this.name = name;
    this.isWhite = isWhite;
    this.isHuman = isHuman;
    this.isBlack = isBlack;
    score = 0;
  }

  void addPoint() {
    score++;
  }

  void resetScore() {
    score = 0;
  }
}
