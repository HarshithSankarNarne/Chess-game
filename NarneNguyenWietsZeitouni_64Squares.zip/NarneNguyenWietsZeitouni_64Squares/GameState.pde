//This is the game state management. This will store instances of all the other classes
//We will use this to manage the game state and keep the game working smoothly

enum GameState {

    MENU,
    PLAYING,
    PUZZLE,
    DRAW,
    DIFFICULTY_SELECT,
    GAME_OVER,
    PAUSED,
    CHECK,
    CHECKMATE
}
