
//We are using the lichess puzzle database and these are all the fields extracted
class Puzzle {

  String puzzleID;
  String firstmove;
  String moves;
  int rating;
  String themes;
  String gameURL;

  Puzzle(String puzzleID, String firstmove, String moves, int rating, String themes, String gameURL) {
    this.puzzleID = puzzleID;
    this.firstmove = firstmove;
    this.moves = moves;
    this.rating = rating;
    this.themes = themes;
    this.gameURL = gameURL;
  }
  boolean checkSolution(String playerMove) {
    String[] solutionMoves = split(moves, "3");
    return playerMove.equals(solutionMoves[1]);
  }

  // Calculate reward based on difficulty
  int calculateRating() {

    if (rating < 1200) {
      return 20;
    } 
    else if (rating < 1800) {
      return 30;
    } 
    else {
      return 50;
    }
  }
}
