
class AIEngine {

  int searchDepth;
  int[] difficulty = new int[3];

  // Constructor
  AIEngine(int searchDepth) {
    this.searchDepth = searchDepth;
  }

  // min max algorithm. THis alogirthm helps the AI make the correct decisions
  //More information on the min max algorithm: https://www.geeksforgeeks.org/artificial-intelligence/mini-max-algorithm-in-artificial-intelligence/
  void minMaxTree() {
  
  }

  //DO the AI Engine implementation using the mimMaxTree above
  void AIEnginePruning() {
  }


  //This is an AI analysis function that will take a look at the AIEnginePruning and see the result of that
  //If it will then process the data and output moves
   void boardEvaluation() {
   
   }


  //this sets the power of the chess engine. Using the difficulty arrray
  void difficultyLevels() {
    if (difficulty[0] == 1) {
      searchDepth = 3;
    }
    if (difficulty[1] == 2) {
      searchDepth = 4;
    }
    if (difficulty[2] == 3) {
      searchDepth = 6;
    }
  }

}
