
import processing.sound.*;

SoundFile clickSound;
SoundFile bgMusic;

PImage bgImage;

PFont menuFont;
PFont titleFont;

int menuState = 0;
int gameMode = 0;

int easyScore = 0;
int medScore = 0;
int hardScore = 0;
int totalXP = 0;


PImage wk, wq, wr, wb, wn, wp;
PImage bk, bq, br, bb, bn, bp;

char[][] board = new char[8][8];

UI ui;

Button btnPuzzles, btnNormal, btnLeader, btnHow, btnQuit;
Button btnEasy, btnMed, btnHard, btnBackDiff;
Button btnBackHow, btnBackLeader, btnBackGame;

class Button {

  float x, y, w, h;
  String label;

  Button(float x, float y, float w, float h, String label) {

    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.label = label;
  }

  boolean isHovered() {

    return mouseX >= x - w / 2 &&
           mouseX <= x + w / 2 &&
           mouseY >= y - h / 2 &&
           mouseY <= y + h / 2;
  }

  void display() {

    textFont(menuFont);
    textAlign(CENTER, CENTER);
    textSize(28);

    fill(0, 80);
    text(label, x + 2, y + 2);

    if (isHovered()) {

      fill(255, 220, 100, 230);
      cursor(HAND);

    } else {

      fill(255, 200);
    }

    text(label, x, y);
  }
}

class UI {

  UI() {
  }

  void drawTitle(String txt, float y) {

    textFont(titleFont);
    textAlign(CENTER, CENTER);
    textSize(64);

    fill(0, 100);
    text(txt, width / 2 + 3, y + 3);

    fill(255, 230);
    text(txt, width / 2, y);
  }


  void drawBackground() {

    if (bgImage != null) {
      image(bgImage, 0, 0, width, height);
    } else {
      background(40, 50, 60);
    }

    noStroke();
    fill(0, 100);
    rect(0, 0, width, height);
  }


  void drawMainMenu() {

    drawTitle("Ultimate\nChess Trainer", 180);

    btnPuzzles.display();
    btnNormal.display();
    btnLeader.display();
    btnHow.display();
    btnQuit.display();
  }


  void drawDifficultyMenu() {

    if (gameMode == 0) {
      drawTitle("Puzzle Difficulty", 200);
    } else {
      drawTitle("Match Difficulty", 200);
    }

    btnEasy.display();
    btnMed.display();
    btnHard.display();
    btnBackDiff.display();
  }


  void drawHowToPlay() {

    drawTitle("How To Play", 150);

    textFont(menuFont);
    textSize(20);
    textAlign(CENTER, CENTER);
    textLeading(36);

    String instructions =
      "Select a game mode and difficulty.\n" +
      "Solve puzzles or play a full match.\n" +
      "Failing to solve a puzzle costs one of your 3 lives.\n\n" +
      "Press H for a hint.\n" +
      "Press M to return to the menu.";

    fill(255, 210);
    text(instructions, width / 2, 370);

    btnBackHow.display();
  }


  void drawLeaderboard() {

    drawTitle("Leaderboard", 150);

    textFont(menuFont);
    textSize(28);
    textAlign(CENTER, CENTER);
    textLeading(50);

    String stats =
      "Easy High Score: " + easyScore + "\n" +
      "Medium High Score: " + medScore + "\n" +
      "Hard High Score: " + hardScore + "\n\n" +
      "Total XP: " + totalXP;

    fill(255, 210);
    text(stats, width / 2, 370);

    btnBackLeader.display();
  }



  void drawBoard() {

    int squareSize = 75;

    int startX = 100;
    int startY = 120;

    drawTitle("Chess Match", 55);

    for (int row = 0; row < 8; row++) {

      for (int col = 0; col < 8; col++) {

        if ((row + col) % 2 == 0) {
          fill(238, 216, 181);
        } else {
          fill(120, 80, 50);
        }

        rect(
          startX + col * squareSize,
          startY + row * squareSize,
          squareSize,
          squareSize
        );

        char piece = board[row][col];

        if (piece != ' ') {

          PImage img = getPieceImage(piece);

          if (img != null) {

            image(
              img,
              startX + col * squareSize + 5,
              startY + row * squareSize + 5,
              squareSize - 10,
              squareSize - 10
            );
          }
        }
      }
    }

    btnBackGame.display();
  }
}

PImage getPieceImage(char piece) {

  switch(piece) {

  case 'K': return wk;
  case 'Q': return wq;
  case 'R': return wr;
  case 'B': return wb;
  case 'N': return wn;
  case 'P': return wp;

  case 'k': return bk;
  case 'q': return bq;
  case 'r': return br;
  case 'b': return bb;
  case 'n': return bn;
  case 'p': return bp;
  }

  return null;
}

void initializeBoard() {

  // Clear board

  for (int row = 0; row < 8; row++) {

    for (int col = 0; col < 8; col++) {

      board[row][col] = ' ';
    }
  }

  // Black pieces

  board[0][0] = 'r';
  board[0][1] = 'n';
  board[0][2] = 'b';
  board[0][3] = 'q';
  board[0][4] = 'k';
  board[0][5] = 'b';
  board[0][6] = 'n';
  board[0][7] = 'r';

  for (int col = 0; col < 8; col++) {
    board[1][col] = 'p';
  }

  // White pieces

  board[7][0] = 'R';
  board[7][1] = 'N';
  board[7][2] = 'B';
  board[7][3] = 'Q';
  board[7][4] = 'K';
  board[7][5] = 'B';
  board[7][6] = 'N';
  board[7][7] = 'R';

  for (int col = 0; col < 8; col++) {
    board[6][col] = 'P';
  }
}



void setup() {

  size(800, 800);
  smooth(8);

  menuFont = createFont("Georgia", 28);
  titleFont = createFont("Georgia", 64);

  // Background

  bgImage = loadImage("bg.jpg");

  // Sounds

  try {

    clickSound = new SoundFile(this, "click.mp3");
    bgMusic = new SoundFile(this, "music.mp3");

    bgMusic.loop();

  } catch (Exception e) {

    println("Sound loading error: " + e.getMessage());
  }

  // Chess pieces

  wk = loadImage("wk.png");
  wq = loadImage("wq.png");
  wr = loadImage("wr.png");
  wb = loadImage("wb.png");
  wn = loadImage("wn.png");
  wp = loadImage("wp.png");

  bk = loadImage("bk.png");
  bq = loadImage("bq.png");
  br = loadImage("br.png");
  bb = loadImage("bb.png");
  bn = loadImage("bn.png");
  bp = loadImage("bp.png");

  // Initialize board

  initializeBoard();

  // Initialize UI

  ui = new UI();

  float cx = width / 2;
  float bw = 320;
  float bh = 44;

  // Main menu buttons

  btnPuzzles = new Button(cx, 300, bw, bh, "Play Puzzles");
  btnNormal = new Button(cx, 365, bw, bh, "Play Match");
  btnLeader = new Button(cx, 430, bw, bh, "Leaderboard");
  btnHow = new Button(cx, 495, bw, bh, "How To Play");
  btnQuit = new Button(cx, 560, bw, bh, "Quit");

  // Difficulty buttons

  btnEasy = new Button(cx, 340, bw, bh, "Easy");
  btnMed = new Button(cx, 405, bw, bh, "Medium");
  btnHard = new Button(cx, 470, bw, bh, "Hard");
  btnBackDiff = new Button(cx, 555, bw, bh, "Back");

  btnBackHow = new Button(cx, 640, bw, bh, "Back");
  btnBackLeader = new Button(cx, 640, bw, bh, "Back");
  btnBackGame = new Button(cx, 740, bw, bh, "Back");
}


void draw() {
  ui.drawBackground();
  cursor(ARROW);
  if (menuState == 0) {
    ui.drawMainMenu();
  } else if (menuState == 1) {
    ui.drawDifficultyMenu();
  } else if (menuState == 2) {
    ui.drawHowToPlay();
  } else if (menuState == 3) {
    ui.drawLeaderboard();
  } else if (menuState == 4) {
    ui.drawBoard();
  }
}


void playClick() {

  if (clickSound != null) {
    clickSound.play();
  }
}

void mousePressed() {

  if (menuState == 0) {
    if (btnPuzzles.isHovered()) {
      playClick();
      gameMode = 0;
      menuState = 1;
    } else if (btnNormal.isHovered()) {
      playClick();
      gameMode = 1;
      menuState = 1;
    } else if (btnLeader.isHovered()) {
      playClick();
      menuState = 3;
    } else if (btnHow.isHovered()) {
      playClick();
      menuState = 2;
    } else if (btnQuit.isHovered()) {
      playClick();
      delay(150);
      exit();
    }
  } else if (menuState == 1) {
    if (btnEasy.isHovered()) {
      playClick();
      menuState = 4;
    } else if (btnMed.isHovered()) {
      playClick();
      menuState = 4;
    } else if (btnHard.isHovered()) {
      playClick();
      menuState = 4;
    } else if (btnBackDiff.isHovered()) {
      playClick();
      menuState = 0;
    }

  } else if (menuState == 2) {
    if (btnBackHow.isHovered()) {
      playClick();
      menuState = 0;
    }
  } else if (menuState == 3) {
    if (btnBackLeader.isHovered()) {
      playClick();
      menuState = 0;
    }

  } else if (menuState == 4) {
    if (btnBackGame.isHovered()) {

      playClick();
      menuState = 1;
    }
  }
}
